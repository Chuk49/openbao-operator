# OpenBao Operator edge chart

Evaluation build from commit 18374c88bfd6d0f4f1c3835df442dae4747083e2. Chart version: 0.5.1-edge.36770847161.1.g18374c88bfd6.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
