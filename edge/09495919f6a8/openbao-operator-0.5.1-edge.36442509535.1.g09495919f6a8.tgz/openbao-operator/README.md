# OpenBao Operator edge chart

Evaluation build from commit 09495919f6a8c9a2b725974a9a192f8754ff9496. Chart version: 0.5.1-edge.36442509535.1.g09495919f6a8.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
