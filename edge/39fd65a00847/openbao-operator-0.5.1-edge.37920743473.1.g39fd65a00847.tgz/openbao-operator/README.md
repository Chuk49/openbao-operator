# OpenBao Operator edge chart

Evaluation build from commit 39fd65a008477dbfc6356d04d7da0561c0a837d4. Chart version: 0.5.1-edge.37920743473.1.g39fd65a00847.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
