# OpenBao Operator edge chart

Evaluation build from commit 80875025186c1ce00aa7a165763becc9733e3dc1. Chart version: 0.5.1-edge.37492881279.1.g80875025186c.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
