# OpenBao Operator edge chart

Evaluation build from commit 657ee47f5010c7fe154e96dd4fcd3b5c7555e5e6. Chart version: 0.5.1-edge.37457270511.1.g657ee47f5010.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
