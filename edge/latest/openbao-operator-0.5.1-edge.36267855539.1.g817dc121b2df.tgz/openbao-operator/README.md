# OpenBao Operator edge chart

Evaluation build from commit 817dc121b2df02d52cddcd10041fa99447fde97c. Chart version: 0.5.1-edge.36267855539.1.g817dc121b2df.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
