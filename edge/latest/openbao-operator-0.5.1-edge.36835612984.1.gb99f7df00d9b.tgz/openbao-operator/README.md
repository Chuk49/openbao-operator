# OpenBao Operator edge chart

Evaluation build from commit b99f7df00d9b5ebdd2f2afae74c1989a15d9a96a. Chart version: 0.5.1-edge.36835612984.1.gb99f7df00d9b.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
