# OpenBao Operator edge chart

Evaluation build from commit d83af36fbadd79b65bc6f5452cc1226776771248. Chart version: 0.5.1-edge.36828184116.1.gd83af36fbadd.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
