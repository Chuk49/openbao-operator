# OpenBao Operator edge chart

Evaluation build from commit 0c6cc726cd51aedc3e7fa11acf8fe14ea4c164ea. Chart version: 0.5.1-edge.37849646017.1.g0c6cc726cd51.

Install this chart from oci://ghcr.io/dc-tec/charts-edge/openbao-operator using the exact version.
The controller, Provisioner, and default helper images are pinned to the verified candidate digests.
This repository is not registered in Artifact Hub.

See https://dc-tec.github.io/openbao-operator/next/docs/get-started/install/ for installation and CRD upgrade steps.
